GlowTrack 90-Day Skin Routine
1. Open index.html in a browser to use the tracker.
2. Set Morning and Night reminder times and enable browser notifications.
3. The tracker saves progress locally in the browser.
4. For reliable background notifications when the app is closed, host the files on HTTPS and add a service worker/PWA notification scheduler; a plain local HTML file cannot guarantee background notifications.
5. The routine is based on the user's existing Plum kit and is a skincare tracker, not medical advice.
